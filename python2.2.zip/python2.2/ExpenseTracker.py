import datetime

def log_expense():
    """
    Logs a new expense by prompting the user for a description and amount.
    Validates the amount to ensure it's a positive number and appends the
    expense to the file with the current timestamp.
    """
    description = input("Enter expense description: ")
    
    # Loop to validate the amount
    while True:
        try:
            amount = float(input("Enter amount: "))
            if amount < 0:
                raise ValueError("Amount cannot be negative.")
            break
        except ValueError as e:
            print(f"Invalid input: {e}. Please enter a valid numeric value.")
    
    # Open the file in append mode and log the expense
    with open("expenses.txt", "a") as file:
        timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        file.write(f"{timestamp} | {description} | {amount}\n")
    print("Expense logged successfully!")

def display_expenses():
    """
    Displays all recorded expenses by reading them from the file.
    If the file does not exist, it informs the user that no expenses are recorded yet.
    """
    try:
        with open("expenses.txt", "r") as file:
            print("Recorded expenses:")
            for line in file:
                print(line.strip())
    except FileNotFoundError:
        print("No expenses recorded yet.")

def summarize_expenses():
    """
    Summarizes the total expenses by reading from the file and calculating
    the cumulative amount spent. If the file does not exist, it informs the user.
    """
    total = 0.0
    try:
        with open("expenses.txt", "r") as file:
            for line in file:
                parts = line.strip().split(" | ")
                total += float(parts[2])
        print(f"Total expenses: {total}")
    except FileNotFoundError:
        print("No expenses recorded yet.")

def main():
    """
    Main function that provides a menu interface for the user to log an expense,
    display all expenses, summarize total expenses, or exit the program.
    """
    while True:
        print("\nExpense Tracker")
        print("1. Log an expense")
        print("2. Display all expenses")
        print("3. Summarize total expenses")
        print("4. Exit")
        choice = input("Choose an option: ")
        
        if choice == '1':
            log_expense()
        elif choice == '2':
            display_expenses()
        elif choice == '3':
            summarize_expenses()
        elif choice == '4':
            break
        else:
            print("Invalid choice. Please choose again.")

if __name__ == "__main__":
    main()
